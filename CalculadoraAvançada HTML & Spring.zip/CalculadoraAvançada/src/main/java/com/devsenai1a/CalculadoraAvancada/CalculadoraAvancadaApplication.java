package com.devsenai1a.CalculadoraAvancada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraAvancadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraAvancadaApplication.class, args);
	}

}
