package com.devsenai1a.CalculadoraAvancada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraAvancadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
